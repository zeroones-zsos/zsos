#! /bin/bash
#From zeroones Security Lab

#Display zsos.icon startup flag (icon)
#===========================================================================================
cat Bin/Icon/zsos.ico

#Get the number of available exploit and POC
#===========================================================================================
Exploit_Quantity=`ls -l  Modules/Exploit/ | grep "^-" | wc -l`
Poc_Quantity=`ls -l  Modules/Poc/ | grep "^-" | wc -l`
echo -n -e "\033[33m [Info]: \033[0m" 
echo "Usable Exploit Number : $Exploit_Quantity and Usable Poc Number : $Poc_Quantity"


#
#===========================================================================================
sh Bin/Command/zsos_menu.sh

